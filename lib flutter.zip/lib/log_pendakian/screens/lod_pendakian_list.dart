import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class LogPendakian {
  final String id;
  final String gunungNama;
  final String? startDate;
  final String? endDate;
  final bool summitReached;
  final int? teamSize;
  final int? rating;
  final String? notes;
  final int? durationDays;

  LogPendakian({
    required this.id,
    required this.gunungNama,
    required this.startDate,
    required this.endDate,
    required this.summitReached,
    required this.teamSize,
    required this.rating,
    required this.notes,
    required this.durationDays,
  });

  factory LogPendakian.fromJson(Map<String, dynamic> json) {
    return LogPendakian(
      id: json['id'] as String,
      gunungNama: (json['gunung_nama'] ?? '-') as String,
      startDate: json['start_date'] as String?,
      endDate: json['end_date'] as String?,
      summitReached: (json['summit_reached'] ?? false) as bool,
      teamSize: json['team_size'] as int?,
      rating: json['rating'] as int?,
      notes: json['notes'] as String?,
      durationDays: json['duration_days'] as int?,
    );
  }
}

class LogPendakianListPage extends StatefulWidget {
  const LogPendakianListPage({super.key});

  @override
  State<LogPendakianListPage> createState() => _LogPendakianListPageState();
}

class _LogPendakianListPageState extends State<LogPendakianListPage> {
  late Future<List<LogPendakian>> _futureLogs;

  @override
  void initState() {
    super.initState();
    _futureLogs = fetchLogs();
  }

  Future<List<LogPendakian>> fetchLogs() async {
    const String baseUrl =
        // "http://rasyad-zulham-gundex.pbp.cs.ui.ac.id";
        "http://127.0.0.1:8000";
    final response = await http.get(
      Uri.parse("$baseUrl/log/json/"),
    );

    if (response.statusCode != 200) {
      throw Exception("Gagal memuat log pendakian: ${response.statusCode}");
    }

    final decoded =
    jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final List<dynamic> rawList = decoded['results'] as List<dynamic>;

    return rawList
        .map((e) => LogPendakian.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Log Pendakian"),
      ),
      body: FutureBuilder<List<LogPendakian>>(
        future: _futureLogs,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Text("Terjadi kesalahan: ${snapshot.error}"),
            );
          }

          final logs = snapshot.data ?? <LogPendakian>[];

          if (logs.isEmpty) {
            return const Center(
              child: Text("Belum ada log pendakian."),
            );
          }

          return ListView.builder(
            itemCount: logs.length,
            itemBuilder: (context, index) {
              final log = logs[index];
              final subtitleLines = <String>[];

              final tanggal =
                  "${log.startDate ?? '-'} s/d ${log.endDate ?? '-'}";
              subtitleLines.add(tanggal);

              final meta = <String>[];
              meta.add(
                  log.summitReached ? "Tercapai puncak" : "Belum sampai puncak");
              if (log.teamSize != null) {
                meta.add("${log.teamSize} orang");
              }
              if (log.rating != null) {
                meta.add("⭐ ${log.rating}/5");
              }
              subtitleLines.add(meta.join(" • "));

              if (log.notes != null && log.notes!.trim().isNotEmpty) {
                subtitleLines.add(log.notes!.trim());
              }

              return Card(
                margin:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: ListTile(
                  title: Text(log.gunungNama),
                  subtitle: Text(subtitleLines.join("\n")),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
