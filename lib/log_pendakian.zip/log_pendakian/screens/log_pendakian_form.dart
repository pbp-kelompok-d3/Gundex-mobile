import 'package:flutter/material.dart';
import 'lod_pendakian_list.dart'; // supaya bisa pakai LogPendakian

class LogPendakianFormPage extends StatefulWidget {
  final LogPendakian? initialLog;

  const LogPendakianFormPage({super.key, this.initialLog});

  @override
  State<LogPendakianFormPage> createState() => _LogPendakianFormPageState();
}

class _LogPendakianFormPageState extends State<LogPendakianFormPage> {
  final _formKey = GlobalKey<FormState>();

  final _gunungController = TextEditingController();
  final _startController = TextEditingController();
  final _endController = TextEditingController();
  final _teamSizeController = TextEditingController();
  final _ratingController = TextEditingController();
  final _notesController = TextEditingController();

  bool _summitReached = false;

  @override
  void initState() {
    super.initState();
    final log = widget.initialLog;
    if (log != null) {
      _gunungController.text = log.gunungNama;
      _startController.text = log.startDate ?? "";
      _endController.text = log.endDate ?? "";
      _summitReached = log.summitReached;
      if (log.teamSize != null) _teamSizeController.text = "${log.teamSize}";
      if (log.rating != null) _ratingController.text = "${log.rating}";
      _notesController.text = log.notes ?? "";
    }
  }

  @override
  void dispose() {
    _gunungController.dispose();
    _startController.dispose();
    _endController.dispose();
    _teamSizeController.dispose();
    _ratingController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickDate(TextEditingController controller) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: now,
    );
    if (picked != null) {
      controller.text = picked.toIso8601String().split('T').first;
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final existing = widget.initialLog;

    final log = LogPendakian(
      id: existing?.id ?? UniqueKey().toString(), // sementara
      gunungNama: _gunungController.text.trim(),
      startDate: _startController.text.trim().isEmpty
          ? null
          : _startController.text.trim(),
      endDate: _endController.text.trim().isEmpty
          ? null
          : _endController.text.trim(),
      summitReached: _summitReached,
      teamSize: _teamSizeController.text.isEmpty
          ? null
          : int.tryParse(_teamSizeController.text),
      rating: _ratingController.text.isEmpty
          ? null
          : int.tryParse(_ratingController.text),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      durationDays: null,
      photoUrl: existing?.photoUrl, // sementara belum ada
    );

    Navigator.pop(context, log);
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.initialLog != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Log Pendakian' : 'Tambah Log Pendakian'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _gunungController,
                decoration: const InputDecoration(
                  labelText: 'Nama gunung',
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Nama gunung wajib diisi';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _startController,
                      readOnly: true,
                      decoration: const InputDecoration(
                        labelText: 'Tanggal mulai (YYYY-MM-DD)',
                      ),
                      onTap: () => _pickDate(_startController),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _endController,
                      readOnly: true,
                      decoration: const InputDecoration(
                        labelText: 'Tanggal selesai (YYYY-MM-DD)',
                      ),
                      onTap: () => _pickDate(_endController),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              CheckboxListTile(
                title: const Text('Puncak tercapai'),
                value: _summitReached,
                onChanged: (val) {
                  setState(() {
                    _summitReached = val ?? false;
                  });
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _teamSizeController,
                decoration: const InputDecoration(
                  labelText: 'Jumlah anggota tim',
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _ratingController,
                decoration: const InputDecoration(
                  labelText: 'Rating (1–5)',
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _notesController,
                decoration: const InputDecoration(
                  labelText: 'Catatan',
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submit,
                child: Text(isEditing ? 'Simpan Perubahan' : 'Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
